package Practica4;

public interface Operaciones {
	
	int elementos(int x, int y);
	String simbolo();
	

}
